// Archivo generado: ejercicio_451.cpp
// Ejercicio: Suma de dos números
#include <iostream>
using namespace std;
int main(){
 double a,b; cout<<"Ingrese dos numeros: "; if(!(cin>>a>>b)) return 0; cout<<"Suma = "<<(a+b)<<"\n"; return 0; }
