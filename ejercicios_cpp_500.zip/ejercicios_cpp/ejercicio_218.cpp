// Archivo generado: ejercicio_218.cpp
// Ejercicio: Convertir minutos a horas y minutos
#include <iostream>
using namespace std;
int main(){ int min; if(!(cin>>min)) return 0; int h = min/60; int m = min%60; cout<<h<<" horas y "<<m<<" minutos\n"; return 0; }
