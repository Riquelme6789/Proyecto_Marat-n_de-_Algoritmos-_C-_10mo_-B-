// Archivo generado: ejercicio_017.cpp
// Ejercicio: Potencia x^y
#include <iostream>
#include <cmath>
using namespace std;
int main(){ double x; int y; if(!(cin>>x>>y)) return 0; cout<<pow(x,y)<<"\n"; return 0; }
