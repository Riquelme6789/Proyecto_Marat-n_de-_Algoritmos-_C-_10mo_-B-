// Archivo generado: ejercicio_481.cpp
// Ejercicio: Convertir Celsius a Fahrenheit
#include <iostream>
using namespace std;
int main(){ double c; cout<<"Ingrese grados Celsius: "; if(!(cin>>c)) return 0; double f = c*9.0/5.0 + 32.0; cout<<"Fahrenheit = "<<f<<"\n"; return 0; }
