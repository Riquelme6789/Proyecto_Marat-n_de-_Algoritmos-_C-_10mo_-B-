// Archivo generado: ejercicio_096.cpp
// Ejercicio: Suma de matrices 2x2
#include <iostream>
using namespace std;
int main(){ int a,b,c,d,e,f,g,h; if(!(std::cin>>a>>b>>c>>d)) return 0; if(!(std::cin>>e>>f>>g>>h)) return 0; cout<<a+e<<" "<<b+f<<"\n"<<c+g<<" "<<d+h<<"\n"; return 0; }
