// Archivo generado: ejercicio_315.cpp
// Ejercicio: Distancia entre dos puntos (2D)
#include <iostream>
#include <cmath>
using namespace std;
int main(){ double x1,y1,x2,y2; if(!(cin>>x1>>y1>>x2>>y2)) return 0; double d=hypot(x2-x1,y2-y1); cout<<d<<"\n"; return 0; }
