// Archivo generado: ejercicio_097.cpp
// Ejercicio: Promedio y desviacion (poblacional)
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int main(){ int n; if(!(cin>>n)) return 0; vector<double>a(n); for(int i=0;i<n;i++) cin>>a[i]; double sum=0; for(double v:a) sum+=v; double mean=sum/n; double s=0; for(double v:a) s+=(v-mean)*(v-mean); double sd = sqrt(s/n); cout<<mean<<" "<<sd<<"\n"; return 0; }
