// Archivo generado: ejercicio_500.cpp
// Ejercicio: Comprobar si arreglo esta ordenado ascendente
#include <iostream>
#include <vector>
using namespace std;
int main(){ int n; if(!(cin>>n)) return 0; vector<int>a(n); for(int i=0;i<n;i++) cin>>a[i]; bool ok=true; for(int i=1;i<n;i++) if(a[i]<a[i-1]) ok=false; cout<<(ok?"Ordenado\n":"No ordenado\n"); return 0; }
