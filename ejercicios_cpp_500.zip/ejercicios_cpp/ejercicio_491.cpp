// Archivo generado: ejercicio_491.cpp
// Ejercicio: Par o impar
#include <iostream>
using namespace std;
int main(){ int n; if(!(cin>>n)) return 0; cout<<(n%2==0?"Par\n":"Impar\n"); return 0; }
