// Archivo generado: ejercicio_049.cpp
// Ejercicio: Contar vocales en una cadena
#include <iostream>
#include <string>
using namespace std;
int main(){ string s; getline(cin,s); if(s.empty()) getline(cin,s); int c=0; for(char ch: s){ char x=tolower((unsigned char)ch); if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u') c++; } cout<<"Vocales="<<c<<"\n"; return 0; }
