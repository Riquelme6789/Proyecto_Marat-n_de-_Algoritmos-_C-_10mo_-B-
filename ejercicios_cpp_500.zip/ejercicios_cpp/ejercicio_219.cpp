// Archivo generado: ejercicio_219.cpp
// Ejercicio: Contar digitos de un numero
#include <iostream>
using namespace std;
int main(){ long long n; if(!(cin>>n)) return 0; n = llabs(n); int c = (n==0)?1:0; while(n>0){ c++; n/=10;} cout<<"Digitos="<<c<<"\n"; return 0; }
